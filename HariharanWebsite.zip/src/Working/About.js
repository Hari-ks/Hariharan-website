import React from "react";

const About=()=>{
    return(
        <div className="about">
            <div>
                <h1 className="aboutheading">About Page</h1>
            </div>
        </div>
    )
}

export default About;


