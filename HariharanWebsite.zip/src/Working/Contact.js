import React from "react";

const Contact=()=>{
    return(
        <div className="contact">
            <div>
                <h1 className="contactheading">Contact Page</h1>
            </div>
        </div>
    )
}

export default Contact;


